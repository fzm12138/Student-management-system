package stu;

public class Score {
    private int s_id=0;
    private String sc_subject="";
    private double score=0.0;
    private String s_teacher="";

    public int getS_id() {
        return s_id;
    }

    public String getSc_subject() {
        return sc_subject;
    }

    public double getScore() {
        return score;
    }

    public String getS_teacher() {
        return s_teacher;
    }

    public void setS_id(int s_id) {
        this.s_id = s_id;
    }

    public void setSc_subject(String sc_subject) {
        this.sc_subject = sc_subject;
    }

    public void setScore(double score) {
        this.score = score;
    }

    public void setS_teacher(String s_teacher) {
        this.s_teacher = s_teacher;
    }

    public void set_Score() {
        System.out.println("请输入学号(Please input the number of the stuent)");
        this.s_id = KeyInput.readInt();

        System.out.println("请输入学科(Please input the subject)");
        this.sc_subject = KeyInput.readString();

        System.out.println("请输入分数(Please input score)");
        this.score = KeyInput.readDouble();

        System.out.println("请输入任课教师(Please input the name of the teacher who teach this subject)");
        this.s_teacher = KeyInput.readString();
    }
}
