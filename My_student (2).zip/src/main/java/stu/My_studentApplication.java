package stu;

import javax.swing.plaf.nimbus.State;
import java.sql.*;

public class My_studentApplication {
    private static String name;
    private static String url="jdbc:mysql://localhost:3306/my_student";
    private static String password="";

    public static void main(String[] args) throws SQLException {

        System.out.println("Please login in\n");
        System.out.println("Input user name");
        name=KeyInput.readString();
        System.out.println("Input password ");
        password=KeyInput.readString();

        User user=new User(url);
        boolean isSuccess=user.getUser(name,password);
        if(!isSuccess){
            System.out.println("Wrong password!");
            return;
        }

        System.out.println("Choose the option");

        int t=0;
        boolean exit=false;
        while(!exit){
             System.out.println("1.查询表(select a table)");
             System.out.println("2.向表中添加记录(add information)");
             System.out.println("3.删除表的记录(delete  information)");
             System.out.println("4.修改某项内容(update information)");
             System.out.println("5.复杂查询操作(预定义的)(complex operations)(Predefined)");
             System.out.println("0.退出(exit)");

             t=KeyInput.readInt();
             switch (t){
                 case 1:db_select(user);break;
                 case 2:db_add(user);break;
                 case 3:db_del(user);break;
                 case 4:db_upodate(user);break;
                 case 5:db_complex(user);break;
                 case 0:exit=true;break;
                 default:System.out.println("nothing happened");break;
             }
         }
    }
    private static void db_complex(User user) throws SQLException {
        boolean exit=false;
        int t=0;
        Student student=new Student();
        Connection connection = DriverManager.getConnection(url,user.getName(),user.getPassword());
        Statement statement = connection.createStatement();

        while(!exit){
            System.out.println("1.查询2020所有获得一等奖学金的学生的成绩、科目和学号和年份" +
                    "(Query the scores, subjects, student number and year of all the first-class scholarship winners in 2020)");
            System.out.println("2.查询所有开设了OS的学院名字(Query the names of all colleges with OS)");
            System.out.println("3.查询在2018或2020年学习了OS和Database的学生" +
                    "(Query students who have studied OS and database in 2018 or 2020)");
            System.out.println("4.查询由fzm教授的学生的成绩(Query the grades of students taught by fzm)");
            System.out.println("5.查询不及格学生的预计毕业时间" +
                    "(Query the expected time of graduation of students who failed)");
            System.out.println("6.查询2020年选了两科及以上科目的学生" +
                    "(Query students who have selected two or more subjects in 2020)");
            System.out.println("7.查询班号为201801的班级的班长在2020年拿到的奖学金等级以及在2020年教授他的老师的名字" +
                    "(Ask the monitor of class 201801 the scholarship level he received in 2020 " +
                    "and the name of the teacher who taught him in 2020)");
            System.out.println("0.退出(exit)");
            t=KeyInput.readInt();
            switch (t){
                case 1:
                    String sql1="select s_id,sc_subject,score,year from score,scholarship where level=1 and year=2020 and sc_year=2020 ;";
                    ResultSet resultSet1 = statement.executeQuery(sql1);
                    System.out.println("student_id    |    subject     |    score");
                    while(resultSet1.next()){
                        System.out.println(
                                resultSet1.getInt("s_id")+"    |    "+resultSet1.getString("sc_subject")+
                                     "    |    "+   resultSet1.getDouble("score")
                        );
                    }
                    break;
                case 2:
                    String sql2="select c_name from college where c_subject='OS';";
                    ResultSet resultSet2 = statement.executeQuery(sql2);
                    System.out.println("college name    |   ");
                    while(resultSet2.next()){
                        System.out.println(
                                resultSet2.getString("c_name")
                        );
                    }
                    break;
                case 3:
                    String sql3="select s_id,s_name from score,student where s_number=s_id and sc_subject='OS' and sc_year in(2018,2020) and\n" +
                            "exists(select* from score where sc_subject='Database') ;";
                    ResultSet resultSet3 = statement.executeQuery(sql3);
                    while(resultSet3.next()){
                        System.out.println(
                                resultSet3.getInt("s_id")+"    |    "+resultSet3.getString("s_name")
                        );
                    }
                    break;
                case 4:
                    String sql4="select s_id,s_name from score,student where s_id=s_number and s_teacher='fzm';";
                    ResultSet resultSet4 = statement.executeQuery(sql4);
                    while(resultSet4.next()){
                        System.out.println(
                                resultSet4.getInt("s_id")+"    |    "+resultSet4.getString("s_name")
                        );
                    }
                    break;
                case 5:
                    String sql5=" select s_number,s_name,graduate_time from student,score where score<60 and s_number=s_id group by s_number;";
                    ResultSet resultSet5 = statement.executeQuery(sql5);
                    while(resultSet5.next()){
                        System.out.println(
                                resultSet5.getInt("s_number")+"    |    "+
                                resultSet5.getString("s_name")+"    |    "+
                                resultSet5.getInt("graduate_time")
                        );
                    }
                    break;
                case 6:
                    String sql6="select s_number,s_name from score,student where sc_year=2020 and s_number=s_id group by s_number having count(sc_subject)>=2;";
                    ResultSet resultSet6 = statement.executeQuery(sql6);
                    while(resultSet6.next()){
                        System.out.println(
                                resultSet6.getInt("s_number")+"    |    "+resultSet6.getString("s_name")
                        );
                    }
                    break;
                case 7:
                    String sql7="select monitor,level,s_teacher,year from class,scholarship,score where year=2020 and c_id=201801 group by s_teacher ;";
                    ResultSet resultSet7 = statement.executeQuery(sql7);
                    while(resultSet7.next()){
                        System.out.println(
                                resultSet7.getString("monitor")+"    |     "+resultSet7.getInt("level")+"    |    "
                                +resultSet7.getString("s_teacher")+"    |    "+resultSet7.getInt("year")
                        );
                    }
                    break;
                case 0:
                    exit=true;
                break;
                default:
                    System.out.println("Nothing happened");
                    break;
            }
        }

    }
    private static void db_upodate(User user) throws SQLException{
        boolean exit=false;
        int t=0;
        Student student=new Student();
        Connection connection = DriverManager.getConnection(url,user.getName(),user.getPassword());
        Statement statement = connection.createStatement();
        while(!exit){
            System.out.println("1.更新学生表中的一条记录(update one record from student table)");
            System.out.println("2.更新教师表中的一条记录(update one record from teacher table)");
            System.out.println("3.更新学院表中的一条记录(update one record from college table)");
            System.out.println("4.更新班级表中的一条记录(update one record from class table)");
            System.out.println("5.更新课程表中的一条记录(update one record from subject table)");
            System.out.println("6.更新分数表中的一条记录(update one record from score table)");
            System.out.println("7.更新奖学金表中的一条记录(update one record from scholarship table)");
            if(user.get_permission())
                System.out.println("8.更新管理员表中的一条记录(update one record from table)");
            System.out.println("0.退出(exit)");
            String element="";
            t=KeyInput.readInt();
            switch (t){
                case 1:
                    System.out.println("请输入你要更新的记录的s_number(只修改专业)(Please input the s_number of the record )(only change major )");
                    //because Im lazy,so just update his major ,you can change it.
                    int num= KeyInput.readInt();
                    System.out.println("请输入你要将他的专业改成什么(please input what major you want to change)");
                    String major= KeyInput.readString();
                    student.setS_number(num);
                    String sql1="update student set major='"+major+"' where s_number="+num+";";
                    PreparedStatement ps = connection.prepareStatement(sql1);
                    ps.executeUpdate();
                    break;
                case 2:
                case 3:
                case 4:
                case 5:
                case 6:
                case 7:
                case 8:
                    if(!user.get_permission()) break;
                case 0:
                default:System.out.println("nothing happened");break;
            }
        }
    }

    private static void  db_del(User user) throws SQLException{
        boolean exit=false;
        int t=0;
        Student student=new Student();
        Connection connection = DriverManager.getConnection(url,user.getName(),user.getPassword());
        Statement statement = connection.createStatement();
        while(!exit){
            System.out.println("1.删除学生表中的一条记录(delete one record from student table)");
            System.out.println("2.删除教师表中的一条记录(delete one record from teacher table)");
            System.out.println("3.删除学院表中的一条记录(delete one record from college table)");
            System.out.println("4.删除班级表中的一条记录(delete one record from class table)");
            System.out.println("5.删除课程表中的一条记录(delete one record from subject table)");
            System.out.println("6.删除分数表中的一条记录(delete one record from score table)");
            System.out.println("7.删除奖学金表中的一条记录(delete one record from users table)");
            if(user.get_permission())
                System.out.println("8.删除管理员表中的一条记录(delete one record from Users' table)");
            System.out.println("0.退出(exit)");
            t=KeyInput.readInt();
            switch (t){
                case 1:
                    System.out.println("根据学号删除一条学生的记录(Delete a student's record according to the student number)");
                    int num= KeyInput.readInt();
                    student.setS_number(num);
                    String deleteSql = "DELETE FROM student WHERE s_number ="+student.getS_number()+";";
                    statement = connection.createStatement();
                    statement.executeUpdate(deleteSql);
                    break;
                case 2:
                case 3:
                case 4:
                case 5:
                case 6:
                case 7:
                case 8:
                    if(!user.get_permission()) break;

                    break;
                case 0:exit=true;break;
                default:System.out.println("Nothing happened");break;
            }
        }
    }
    private static void db_add(User user) throws SQLException{
        boolean exit=false;
        int t=0;
        Connection connection = DriverManager.getConnection(url,user.getName(),user.getPassword());
        Statement statement = connection.createStatement();
        College college=new College();
        My_class my_class=new My_class();
        Scholarship scholarship=new Scholarship();
        Score score=new Score();
        Student student=new Student();
        Subject subject=new Subject();
        Teacher teacher=new Teacher();
        while(!exit){
            System.out.println("1.学生信息表添加记录(add information into student table)");
            System.out.println("2.向教师信息表添加记录(add information into teacher table)");
            System.out.println("3.向学院信息表添加记录(add information into college table)");
            System.out.println("4.向班级信息表添加记录(add information into class table)");
            System.out.println("5.向课程信息表添加记录(add information into subject table)");
            System.out.println("6.向分数信息表添加记录(add information into score table)");
            System.out.println("7.向奖学金信息表添加记录(add information into scholarship table)");
            if(user.get_permission())
                System.out.println("8.向用户信息表添加记录(insert information into users table )");
            System.out.println("0.退出(exit)");
            t=KeyInput.readInt();
            switch (t){
                case 1:
                    student.set_Student();
                    String sql1="insert into  student(s_number,s_name,sex,grade,college,major,admission_time,graduate_time) values (?,?,?,?,?,?,?,?)";
                    PreparedStatement pstmt=connection.prepareStatement(sql1);
                    pstmt.setInt(1,student.getS_number());
                    pstmt.setString(2,student.getS_name());
                    pstmt.setString(3,student.getSex());
                    pstmt.setInt(4,student.getGrade());
                    pstmt.setString(5,student.getCollege());
                    pstmt.setString(6,student.getMajor());
                    pstmt.setInt(7,student.getAdmission_time());
                    pstmt.setInt(8,student.getGraduate_time());
                    int res=pstmt.executeUpdate();//执行sql语句
                    if(res>0){
                        System.out.println("数据录入成功(successful)");
                    }
                    break;
                case 2:
                    teacher.set_Teacher();
                    String sql2="insert into teacher(t_number,t_name,department ,subject,sex,age,work_age) values (?,?,?,?,?,?,?)";
                    pstmt=connection.prepareStatement(sql2);
                    pstmt.setInt(1,teacher.getT_number());
                    pstmt.setString(2,teacher.getT_name());
                    pstmt.setString(3,teacher.getDepartment());
                    pstmt.setString(4,teacher.getSubject());
                    pstmt.setString(5,teacher.getSex());
                    pstmt.setInt(6,teacher.getAge());
                    pstmt.setInt(7,teacher.getWork_age());
                     res=pstmt.executeUpdate();//执行sql语句
                    if(res>0){
                        System.out.println("数据录入成功(successful)");
                    }
                    break;
                case 3:

                    break;
                case 4:

                    break;
                case 5:

                    break;
                case 6:

                    break;
                case 7:

                    break;
                case 8:
                        if(!user.get_permission()) break;
                    break;
                case 0:exit=true;
                    break;
                default:System.out.println("Nothing happened");break;

            }
        }

    }










    private static void db_select(User user) throws SQLException {
        boolean exit=false;
        int t=0;

        Connection connection = DriverManager.getConnection(url,user.getName(),user.getPassword());
        Statement statement = connection.createStatement();
        String sql1 = "select * from student";
        String sql2 = "select * from teacher";
        String sql3 = "select * from college";
        String sql4 = "select * from class";
        String sql5 = "select * from subject";
        String sql6 = "select * from score";
        String sql7 = "select * from scholarship";
        String sql8 = "select * from users";

        while(!exit){
            System.out.println("1.查询学生表(select student table)");
            System.out.println("2.查询教师表(select teacher table)");
            System.out.println("3.查询学院表(select college table)");
            System.out.println("4.查询班级表(select class table)");
            System.out.println("5.查询课程表(select subject table)");
            System.out.println("6.查询分数表(select score table)");
            System.out.println("7.查询奖学金表(select scholarship table)");


            if(user.get_permission()==true)
                System.out.println("8.查询管理员表");
            System.out.println("0.退出");
            t=KeyInput.readInt();
            switch (t){
                case 1:
                    ResultSet resultSet1 = statement.executeQuery(sql1);
                    System.out.println("s_number   |    s_name   |    sex    |    " +
                            "grade   |   college    |    major    |    admission_time    |    graduate_time ");
                    while(resultSet1.next()){
                        System.out.println(
                                resultSet1.getInt("s_number")+"   |   "
                                +resultSet1.getString("s_name")+"   |   "+resultSet1.getString("sex")+"   |   "+
                                resultSet1.getInt("grade")+"   |   "+resultSet1.getString("college")+"   |   "+
                                resultSet1.getString("major")+"   |   "+resultSet1.getInt("admission_time")+"   |   "+
                                resultSet1.getInt("graduate_time")
                        );
                    }

                    break;
                case 2:
                    ResultSet resultSet2 = statement.executeQuery(sql2);
                    System.out.println("t_number    |    t_name    |    department    |    subject    |    sex    |    " +
                            "age    |    work_age");
                    while(resultSet2.next()){
                    System.out.println(
                            resultSet2.getInt("t_number")+"   |   "+resultSet2.getString("t_name")+
                            resultSet2.getString("department")+"   |   "+resultSet2.getString("subject")+"   |   "+
                            resultSet2.getString("sex")+"   |   "+resultSet2.getInt("age")+"   |   "+
                            resultSet2.getInt("work_age")
                            );
                    }

                    break;
                case 3:
                    ResultSet resultSet3 = statement.executeQuery(sql3);
                    System.out.println("c_name   |   c_teacher    |    c_subject");

                    while(resultSet3.next()){
                        System.out.println(
                                resultSet3.getString("c_name")+"   |   "+resultSet3.getString("c_teacher")+"   |   "+
                                resultSet3.getString("c_subject")
                        );
                    }

                    break;
                case 4:
                    ResultSet resultSet4 = statement.executeQuery(sql4);
                    System.out.println("c_id    |    c_college major     |    monitor");
                    while(resultSet4.next()){
                        System.out.println(
                                resultSet4.getInt("c_id")+"   |   "+resultSet4.getString("c_college")+"   |   "+
                                resultSet4.getString("major")+"   |   "+resultSet4.getString("monitor")
                        );
                    }
                    break;
                case 5:
                    ResultSet resultSet5 = statement.executeQuery(sql5);
                    System.out.println("sub_name   |    department   |    sub_teacher");
                    while (resultSet5.next()){
                        System.out.println(
                                resultSet5.getString("sub_name")+"   |   "+resultSet5.getString("department")+"   |   "+
                                resultSet5.getString("sub_teacher")
                        );
                    }

                    break;
                case 6:
                    ResultSet resultSet6 = statement.executeQuery(sql6);
                    System.out.println("s_id   |   sc_subject    |    score    |    s_teacher");
                    while(resultSet6.next()){
                        System.out.println(
                                resultSet6.getInt("s_id")+"   |   "+resultSet6.getString("sc_subject")+"   |   "+
                                resultSet6.getDouble("score")+"   |   "+resultSet6.getString("s_teacher")
                        );
                    }
                    break;
                case 7:
                    ResultSet resultSet7 = statement.executeQuery(sql7);
                    System.out.println("sh_id    |    level    |    year");
                    while(resultSet7.next()){
                        System.out.println(
                                resultSet7.getInt("sh_id")+"   |   "+ resultSet7.getInt("level")+"   |   "+
                                resultSet7.getInt("year")
                        );
                    }
                    break;
                case 8:
                    if(!user.get_permission()) break;
                    ResultSet resultSet8 = statement.executeQuery(sql8);
                    System.out.println("id    |    name    |    password");
                    while(resultSet8.next()){
                        System.out.println(
                                resultSet8.getInt("id")+"   |   "+resultSet8.getString("name")+
                                resultSet8.getString("password")
                        );
                    }
                    break;
                case 0:
                    exit=true;
                    break;
                default:System.out.println("Nothing happened");break;

            }
        }
    }
}

// System.out.println("请输入(Please input)");
/*select s_id,s_name from score,student where s_number=s_id and sc_subject='OS' and sc_year in(2018,2020) and
exists(select* from score where sc_subject='Database');
*/