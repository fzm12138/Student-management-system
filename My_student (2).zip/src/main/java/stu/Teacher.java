package stu;

import javax.swing.*;

public class Teacher {
    private int t_number=0;
    //工号 teachers' work number
    private String t_name="";
    //名字 teachers' name
    private String department="";
    //学院 teachers' college
    private String subject="";
    //学科 teachers' subject
    private String sex="";
    // 性别 teachers' sex
    private int age=0;
    //年龄 teachers' age
    private int work_age=0;
    //工龄 teachers' work age


    public void setT_number(int t_number) {
        this.t_number = t_number;
    }

    public void setT_name(String t_name) {
        this.t_name = t_name;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public void setWork_age(int work_age) {
        this.work_age = work_age;
    }

    public void set_Teacher() {
        System.out.println("请输入教师编号(Please input teacher's number)");
        this.t_number =KeyInput.readInt();

        System.out.println("请输入教师姓名(Please input teacher's name)");
        this.t_name = KeyInput.readString();

        System.out.println("请输入教师的学院(Please input teacher's college)");
        this.department = KeyInput.readString();

        System.out.println("请输入教师教的学科(Please input the subject this teacher teach)");
        this.subject = KeyInput.readString();

        System.out.println("请输入教师性别(Please input teacher's sex)");
        this.sex = KeyInput.readString();

        System.out.println("请输入教师年龄(Please input teacher's age)");
        this.age = KeyInput.readInt();

        System.out.println("请输入工作年龄(Please input teacher's work age)");
        this.work_age = KeyInput.readInt();
    }

    public int getT_number() {
        return t_number;
    }

    public String getT_name() {
        return t_name;
    }

    public String getDepartment() {
        return department;
    }

    public String getSubject() {
        return subject;
    }

    public String getSex() {
        return sex;
    }

    public int getAge() {
        return age;
    }

    public int getWork_age() {
        return work_age;
    }




}
