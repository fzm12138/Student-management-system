package stu;

public class My_class {
    private int c_id=0;
    private String c_college="";
    private String major="";
    private String monitor="";

    public void setC_id(int c_id) {
        this.c_id = c_id;
    }

    public void setC_college(String c_college) {
        this.c_college = c_college;
    }

    public void setMajor(String major) {
        this.major = major;
    }

    public void setMonitor(String monitor) {
        this.monitor = monitor;
    }

    public void set_My_class() {
        System.out.println("请输入班号(Please input the number of the class)");
        this.c_id =KeyInput.readInt();

        System.out.println("请输入班级所属学院(Please input which college does this class belong to)");
        this.c_college = KeyInput.readString();

        System.out.println("请输入这个班级的专业(Please input the major of the class)");
        this.major = KeyInput.readString();

        System.out.println("请输入班长名字(Please input the name of the monitor)");
        this.monitor = KeyInput.readString();
    }

    public int getC_id() {
        return c_id;
    }

    public String getC_college() {
        return c_college;
    }

    public String getMajor() {
        return major;
    }

    public String getMonitor() {
        return monitor;
    }
}
