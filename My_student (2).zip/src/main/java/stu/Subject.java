package stu;

public class Subject {
    private String sub_name="";
    private String department="";
    private String sub_teacher="";

    public void setSub_name(String sub_name) {
        this.sub_name = sub_name;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public void setSub_teacher(String sub_teacher) {
        this.sub_teacher = sub_teacher;
    }

    public void set_Subject() {
        System.out.println("请输入课名(Please input the name of the subject)");
        this.sub_name = KeyInput.readString();

        System.out.println("请输入开设这个课程的学院(Please input the college that opened the course)");
        this.department = KeyInput.readString();

        System.out.println("请输入教这门课的老师(Please input the teacher's name)");
        this.sub_teacher = KeyInput.readString();
    }

    public String getSub_name() {
        return sub_name;
    }

    public String getDepartment() {
        return department;
    }

    public String getSub_teacher() {
        return sub_teacher;
    }
}
