package stu;

public class Scholarship {
 private int sh_id=0;
 private int level=0;
 private int year=0;

    public int getSh_id() {
        return sh_id;
    }

    public int getLevel() {
        return level;
    }

    public int getYear() {
        return year;
    }

    public void setSh_id(int sh_id) {
        this.sh_id = sh_id;
    }

    public void setLevel(int level) {
        this.level = level;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public void set_Scholarship() {
        System.out.println("请输入获得奖学金的学生的学号(Please input the number of the student who won the scholarship)");
        this.sh_id = KeyInput.readInt();

        System.out.println("请输入奖学金等级(Please input the level of the scholarship)");
        this.level = KeyInput.readInt();

        System.out.println("请输入获奖的年份(Please input the year when he got scholarship)");
        this.year = KeyInput.readInt();
    }
}
