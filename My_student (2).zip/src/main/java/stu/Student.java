package stu;

public class Student {
    private int s_number=0;

    private String s_name="";

    private String sex="";

    private int grade=0;

    private String college="";

    private String major="";

    private int admission_time=0;

    private int graduate_time=0;

    public void setS_number(int s_number) {
        this.s_number = s_number;
    }

    public void setS_name(String s_name) {
        this.s_name = s_name;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public void setGrade(int grade) {
        this.grade = grade;
    }

    public void setCollege(String college) {
        this.college = college;
    }

    public void setMajor(String major) {
        this.major = major;
    }

    public void setAdmission_time(int admission_time) {
        this.admission_time = admission_time;
    }

    public void setGraduate_time(int graduate_time) {
        this.graduate_time = graduate_time;
    }

    public void set_Student(){
        System.out.println("请输入学号(Please input number)");
        this.s_number=KeyInput.readInt();

        System.out.println("请输入姓名(Please input name)");
        this.s_name=KeyInput.readString();

        System.out.println("请输入性别(Please input sex)");
        this.sex=KeyInput.readString();

        System.out.println("请输入年级(Please input grade)");
        this.grade=KeyInput.readInt();

        System.out.println("请输入学院(Please input college)");
        this.college=KeyInput.readString();

        System.out.println("请输入专业(Please input major)");
        this.major=KeyInput.readString();

        System.out.println("请输入录取时间(Please input admission time)");
        this.admission_time=KeyInput.readInt();

        System.out.println("请输入预期毕业时间(Please input graduate time)");
        this.graduate_time=KeyInput.readInt();
    }

    public int getS_number() {
        return s_number;
    }

    public String getS_name() {
        return s_name;
    }

    public String getSex() {
        return sex;
    }

    public int getGrade() {
        return grade;
    }

    public String getCollege() {
        return college;
    }

    public String getMajor() {
        return major;
    }

    public int getAdmission_time() {
        return admission_time;
    }

    public int getGraduate_time() {
        return graduate_time;
    }



}
