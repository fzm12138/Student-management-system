package stu;

public class College {
    private String c_name="";
    //学院名字 college's name
    private String c_teacher="";
    //学院主任名字 college's director
    private String c_subject="";
    //学院主任教授的科目 Subjects taught by the director of the College
    public String getC_name() {
        return c_name;
    }

    public String getC_teacher() {
        return c_teacher;
    }

    public String getC_subject() {
        return c_subject;
    }

    public void setC_name(String c_name) {
        this.c_name = c_name;
    }

    public void setC_teacher(String c_teacher) {
        this.c_teacher = c_teacher;
    }

    public void setC_subject(String c_subject) {
        this.c_subject = c_subject;
    }

    public void set_College() {
        System.out.println("请输入学院名称(Please input college's name)");
        this.c_name = KeyInput.readString();

        System.out.println("请输入学院主任名字(Please input college's director )");
        this.c_teacher = KeyInput.readString();

        System.out.println("请输入学院主任教的科目(Please input Subject taught by the director of the College)");
        this.c_subject = KeyInput.readString();
    }
}
