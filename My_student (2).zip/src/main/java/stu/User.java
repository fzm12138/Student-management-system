package stu;

import java.sql.*;

public class User {
    private String url="";
    private int id;
    private   boolean permission=false;
    private String name="root";
    private String password="123456";
    public User(String url){
        this.url=url;
    }

    public int getId() {
        return id;
    }
    public boolean get_permission(){
        return this.permission;
    }
    public String getName(){
        return this.name;
    }
    public String getPassword(){
        return this.password;
    }
    public String getUrl(){
        return this.url;
    }
    public boolean getUser(String name, String password) throws SQLException {
        Connection connection = DriverManager.getConnection(url,this.name,this.password);
        Statement statement = connection.createStatement();
        String sql = "select * from users where name = '"+name+ "' "
                + "and password = '"+password+"'";

        ResultSet resultSet = statement.executeQuery(sql);
        if(resultSet.next()){
            System.out.println("successful login \n");
            this.id=resultSet.getInt("id");
            if (this.id==666){//if user's id==666,then he has highest permission
                this.permission=true;
            }
            return true;
        }
        else System.out.println("login failed");
        System.out.println(resultSet.getInt("id"));
        return false;
    }
}
