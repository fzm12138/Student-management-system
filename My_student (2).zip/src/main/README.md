## Please read this before using it.
- Because I'm lazy,so some likely operations I only write 1 or two of them,so its not the full version
- Maybe I'll update it
- You can choose the options we set.
- You can change the options or users as your wish.
- Project has no ui,this project is just for study so ui is not necessary.
- default mysql address is localhost:3306
- mysql_version:5.5.17
- Project has 7 tables:users,student,teacher,subject,class,scholarship,college,score.
- run cmd and execute codes from create.md and insert.md to create the database and tables .
- Its maybe not a good project,I just study how to use sql with this project
- This project controls students information's database. 
**default user of mysql(To login when run the project):**

**user:root**
**password:123456**

**default user of database:**

**user:fzm**

**password:123456**

 *Written by 范子鸣*