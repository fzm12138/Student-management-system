```mysql
# users table
insert into users values(666,'fzm',123456);
# student table
insert into  student values 
(20183152,'Fanziming','man',2018,'CS','IOT',20180910,20220705),
(20183137,'Liangce','man',2018,'CS','IOT',20180910,20220705),
(20175321,'Wuxie','man',2017,'CS','IOT',20170910,20200705),
(20201234,'Jolyne','female',2020,'Biology','Biology',20200910,20240705),
(20165321,'jojo','man',2017,'Economics','Finance',20170910,20200705),
(20156223,'Jinlian','female',2015,'Economics','Finance',20150910,20190705),
(20182563,'Lurenjia','man',2018,'History','Archaeology',20180910,20220705);


# <----------------------------------------------------------------------------------->
# teacher table
insert into teacher(t_number,t_name,department ,subject,sex,age,work_age)
values(1327,'Jonathan','History','Relics','man',24,1),
(1001,'Joseph','Economics','Marketing','man',65,32),
(2567,'Jotaro','Biology','Marine Biology','man',32,8),
(9527,'fzm','CS','OS','man',21,1),
(2345,'Yuanyuan','CS','Database','female',28,6),
(7788,'Liangliang','Electronic','OS','man',55,30);
# <----------------------------------------------------------------------------------->
# subject table
insert into subject(sub_name ,department ,sub_teacher)
values('Relics','History','Jonathan'),
('Marketing','Economics','Joseph'),
('OS','CS','fzm'),
('Marine Biology','Biology','Jotaro'),
('Database','CS','Yuanyuan'),
('OS','Electronic','Liangliang');

# <----------------------------------------------------------------------------------->
# score table
insert into score(s_id ,sc_subject,score ,s_teacher,sc_year) values
(20183152,'Relics',100,'Jonathan',2018),
(20183152,'Marketing',100,'Joseph',2018),
(20183152,'OS',100,'fzm',2019),
(20183152,'Database',100,'Yuanyuan',2020),
(20183137,'OS',100,'Liangliang',2018),
(20183137,'Database',100,'Yuanyuan',2019),
(20183137,'Relics',65,'Jonathan',2020),
(20201234,'Relics',85,'Jonathan',2020),
(20201234,'Marine Biology',95,'Jotaro',2020),
(20201234,'Database',84,'Yuanyuan',2020),
(20175321,'Database',77,'Yuanyuan',2018),
(20175321,'OS',50,'Liangliang',2017),
(20165321,'Marketing',92,'Joseph',2016),
(20165321,'OS',59,'Liangliang',2020),
(20165321,'OS',65,'fzm',2018),
(20156223,'OS',45,'fzm',2015),
(20156223,'Marine Biology',0,'Jotaro',2016),
(20182563,'Relics',100,'Jonathan',2020),
(20182563,'Marketing',100,'Joseph',2020),
(20182563,'OS',100,'fzm',2019),
(20182563,'Database',100,'Yuanyuan',2019);


# <----------------------------------------------------------------------------------->
# scholarship table
insert into scholarship(sh_id,level,year)
values(20183152,1,2019),
(20183152,1,2020),
(20183152,1,2021),
(20183152,1,2022),
(20183137,3,2019),
(20183137,2,2020),
(20183137,1,2021),
(20183137,1,2022);

# <----------------------------------------------------------------------------------->
# class table
insert into class(c_id,c_college,major ,monitor)values
(201801,'CS','IOT','Fanziming'),
(201802,'CS','IOT','Liangce'),
(202001,'Biology','Biology','Jolyne'),
(201821,'History','Archaeology','Lurenjia');
# <----------------------------------------------------------------------------------->
# college table
insert into college(c_name ,c_teacher,c_subject) value
('CS','fzm','OS'),
('Biology','Jotaro','Marine Biology'),
('Economics','Joseph','Marketing'),
('History','Jonathan','Relics'),
('Electronic','Liangliang','OS');




















```