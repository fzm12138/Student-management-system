```mysql
# create the database
 create database my_student;
# create users table
create table users(id int,name char(20),password char(20));
# student table
 create table student(s_number int,s_name char(20),sex char(20),
 grade int,college char(20),major char(20),admission_time int,graduate_time int);

# <----------------------------------------------------------------------------------->
#  teacher table
 create table teacher(t_number int,t_name char(20),department char(20),subject char(20),
 sex char(20),age int,work_age int);

# <----------------------------------------------------------------------------------->
# subject table
create table subject(sub_name char(20),department char(20),sub_teacher char(20));

# <----------------------------------------------------------------------------------->
# score table
create table score(s_id int,sc_subject char(20),score double,s_teacher char(20),sc_year int);

# <----------------------------------------------------------------------------------->
# scholarship table
create table scholarship(sh_id int,level int,year int);

# <----------------------------------------------------------------------------------->
# class table
create table class(c_id int,c_college char(20),major char(20),monitor char(20));

# college table
create table college(c_name char(20),c_teacher char(20),c_subject char(20));
```